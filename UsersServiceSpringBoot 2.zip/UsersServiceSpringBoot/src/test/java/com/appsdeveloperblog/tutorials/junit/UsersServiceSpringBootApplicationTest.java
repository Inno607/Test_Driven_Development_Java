package com.appsdeveloperblog.tutorials.junit;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@Disabled
@SpringBootTest
class UsersServiceSpringBootApplicationTest {
    @Test
    void contextLoads() {
    }
}