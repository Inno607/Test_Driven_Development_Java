package com.training;

public class Calculator {

    public int intDivision(int dividend, int devisor) {
        return dividend/devisor;
    }

    public int integerSubtraction(int minuend, int subtrahend) {
        return minuend - subtrahend;
    }

    public int integerAddition(int num1, int num2) {
        return num1 + num2;
    }


}
